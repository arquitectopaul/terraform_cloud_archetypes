'use strict';
const https = require('http');
const jwt_decode = require('jwt-decode');

const Effect = {
    Allow: "Allow",
    Deny: "Deny"
};

module.exports.opaExecution = async (event) => {

    try {
        const { authorizationToken, methodArn } = event;

        const { method: reqMethod, path: reqPath } = await extractMethodArnData(methodArn);

        const jwtToken = authorizationToken.split(" ")[1];
        const tokenPayload = jwt_decode(jwtToken);

        const { username: tokenUsername, "cognito:groups": roleNames } = tokenPayload;

        const opaReqInput = {
            input: {
                roleName: roleNames[0],
                apiMethod: reqMethod,
                apiPath: reqPath
            }
        };

        const serializedOpaReqInput = JSON.stringify(opaReqInput);

        const options = {
            hostname: process.env.OPA_AGENT_URI,
            port: process.env.OPA_AGENT_PORT,
            path: process.env.OPA_AGENT_PATH,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': serializedOpaReqInput.length
            },
        };

        // Consulta al API Rest de OPA
        const opaRes = await doRequest(options, serializedOpaReqInput);

        if (opaRes.result.pe.com.banbif.designpatterns.archetype.apirules.allow && tokenUsername) {
            return await generatePolicy(Effect.Allow, methodArn, tokenUsername);
        }

        return await generatePolicy(Effect.Deny, methodArn);
    } catch (error) {
        console.error(`Sucedio un error inesperado:`, error);
        return await generatePolicy(Effect.Deny);
    }
};

/**
 * Realiza la consulta del API Rest de OPA
 *
 * @param {Object} options
 * @param {Object} serializedData
 * @return {Promise} a promise of request
 */
function doRequest(options, serializedData) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            res.setEncoding("utf8");
            let responseBody = "";

            res.on("data", (chunk) => {
                responseBody += chunk;
            });

            res.on("end", () => {
                resolve(JSON.parse(responseBody));
            });
        });

        req.on("error", (err) => {
            reject(err);
        });

        req.write(serializedData);
        req.end();
    });
}

/**
 * Genera la politica para denegar o permitir acceso al recurso para el API Gateway
 *
 * @param {String} principalId
 * @param {String} effect
 * @param {Object} resource
 * @return {Promise} a promise of request
 */
const generatePolicy = async (effect, resource, principalId) => {
    return {
        principalId,
        policyDocument: {
            Version: '2012-10-17',
            Statement: [{
                Action: 'execute-api:Invoke',
                Effect: effect,
                Resource: resource || `execute-api:/*`,
            }]
        }
    };
};

// Extra el metodo y el path del recurso ARN que viene del API Gateway
const extractMethodArnData = async (arn) => {

    const arnParts = arn.split(':');
    
    const region = arnParts[3];
    const endpointArn = arnParts[5];

    const endpointArnParts = endpointArn.split('/');

    const [apiId, stage, method, ...pathParts] = endpointArnParts;

    const path = pathParts ? `/${pathParts.join('/')}` : '/';
    
    return {
        region,
        apiId,
        stage,
        method,
        path
    };
};